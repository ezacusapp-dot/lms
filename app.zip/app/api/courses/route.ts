import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";


// ================= CREATE COURSE =================
export async function POST(req: Request) {
  try {
    const body = await req.json();

    const {
      title,
      categoryId,
      levelId,
      duration,
      description,
      createdBy,
    } = body;

    if (!title) {
      return NextResponse.json(
        { status: false, message: "Title is required" },
        { status: 400 }
      );
    }

    // ✅ Duplicate check
    const existing = await prisma.courses.findFirst({
      where: { title },
    });

    if (existing) {
      return NextResponse.json(
        { status: false, message: "Course already exists" },
        { status: 409 }
      );
    }

    // ✅ Create course with relations
    const course = await prisma.courses.create({
      data: {
        title,
        duration,
        description,
        createdBy,

        ...(categoryId && {
          CourseCategory: {
            connect: { id: categoryId },
          },
        }),

        ...(levelId && {
          CourseLevel: {
            connect: { id: levelId },
          },
        }),
      },
    });

    return NextResponse.json({
      status: true,
      message: "Course created successfully",
      data: course,
    });

  } catch (error: any) {
    console.error(error);
    return NextResponse.json(
      { status: false, message: error.message },
      { status: 500 }
    );
  }
}


// ================= GET COURSES =================
export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);

    const page = parseInt(searchParams.get("page") || "1");
    const limit = parseInt(searchParams.get("limit") || "10");
    const search = searchParams.get("search") || "";
    const categoryId = searchParams.get("categoryId") || "";
    const levelId = searchParams.get("levelId") || "";

    const skip = (page - 1) * limit;

    // ✅ Clean WHERE
    const where: any = {};

    if (search) {
      where.title = {
        contains: search,
        mode: "insensitive",
      };
    }

    if (categoryId) {
      where.categoryId = categoryId;
    }

    if (levelId) {
      where.levelId = levelId;
    }

    // ✅ Count
    const total = await prisma.courses.count({ where });

    // ✅ Fetch
    const courses = await prisma.courses.findMany({
      where,
      skip,
      take: limit,
      orderBy: {
        createdAt: "desc",
      },
      include: {
        CourseCategory: {
          select: {
            id: true,
            name: true,
          },
        },
        CourseLevel: {
          select: {
            id: true,
            name: true,
          },
        },
        Modules: {
          orderBy: { order: "asc" },
        },
      },
    });

    return NextResponse.json({
      status: true,
      data: courses,
      meta: {
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit),
      },
    });

  } catch (error: any) {
    console.error(error);
    return NextResponse.json(
      { status: false, message: error.message },
      { status: 500 }
    );
  }
}